#!/usr/bin/env python

command = testtex_command ("src/horizgrid.tx", " --scalest 1 4")
outputs = [ "out.exr" ]
