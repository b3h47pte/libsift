#!/usr/bin/env python 

command += "python src/test_typedesc.py > out.txt"

